import json
from urllib.request import urlopen
import random
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dataset_creation.client_sample import LLMClient


class ContextPool:
    def __init__(self):
        super().__init__()
        r = urlopen("https://instruct-pix2pix.eecs.berkeley.edu/human-written-prompts.jsonl")
        self.context_dict = [json.loads(l) for l in r]

        self.input_edit_templ = "\"input\": \"{}\", \"edit\": {} "
        self.input_edit_output_templ = "\"input\": \"{}\", \"edit\": \"{}\", \"output\": {}"

        self.llm_client = LLMClient()

    def get_n_context(self, num=5):
        # import pdb; pdb.set_trace()
        samples = random.sample(self.context_dict, num)
        input_edit_str = [self.input_edit_templ.format(s['input'], s['edit']) for s in samples]
        input_edit_output_str = [self.input_edit_output_templ.format(s['input'], s['edit'], s['output']) for s in samples]
        input_edit_str = '\n'.join(input_edit_str)
        input_edit_output_str = '\n'.join(input_edit_output_str)
        return input_edit_str, input_edit_output_str

    def query_edit(self, input_caption):
        # import pdb; pdb.set_trace()
        # instruction = 'Instruction: Based on the following examples, finish the \"edit\" sentence.\n'
        instruction = ''
        input_edit_str, input_edit_output_str = self.get_n_context()
        q_input_edit_str = "\n".join([input_edit_str, input_caption])
        answer = self.ask_llm(instruction+q_input_edit_str)
        return answer

    def query_output(self, input_caption):

        input_edit_str, input_edit_output_str = self.get_n_context(5)
        q_input_edit_output_str = "\n".join([input_edit_output_str, input_caption])
        # import pdb; pdb.set_trace()
        answer = self.ask_llm(q_input_edit_output_str)
        return answer

    def ask_llm(self, prompt):
        stream_request_data = {
            "prompt": prompt,
            "max_tokens": 500,
            "temperature": 0.6,
            "top_p": 1,
            "n": 1,
            "stream": True,
            "logprobs": None,
            "stop": "\n"
        }
        for response in self.llm_client.send_stream_request('text-chat-davinci-002', stream_request_data):
            # print('prompt: ', prompt)
            # print(response['choices'][0]['text'])
            # import pdb; pdb.set_trace()
            # print(response['choices'])
            return response['choices'][0]['text']


if __name__ == '__main__':
    context_pool = ContextPool()
    for i in range(10):
        idx = random.randint(0, 670)
        input_caption = context_pool.input_edit_templ.format(context_pool.context_dict[idx]['input'], "")
        # instruction = ''
        # question = instruction+input_caption
        # print(question)
        print('gt: ', context_pool.context_dict[idx]['edit'])
        print('pred: ', end='')
        print(context_pool.query_edit(input_caption))

    # for i in range(10):
    #     idx = random.randint(0, 670)
    #     input_caption = context_pool.input_edit_templ.format(context_pool.context_dict[idx]['input'], context_pool.context_dict[idx]['edit'])
    #     instruction = '\n\nInstruction: Based on the above examples, complete \"output\".\n'
    #
    #     question = instruction+input_caption
    #     print(question)
    #     print('gt: ', context_pool.context_dict[idx]['output'])
    #     context_pool.query_output(question)
    #     print('\n')
